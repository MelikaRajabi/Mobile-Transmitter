%% Calculating J

clear;
clc;

n = 6;
Z0 = 50;
FBW = 0.02;

Y0 = 1/Z0;

J = zeros(1, n+1);
g = [1, 0.9940, 1.4131, 1.8933, 1.5506, 1.7253, 0.8141, 1.2210];

for i = 1:n+1
    if (i == 1 || i == n+1)
        J(i) = Y0 * sqrt ( (pi * FBW)/( 2 * g(i)*g(i+1) ) );         
    else
        J(i) = (Y0 * pi * FBW)/( 2 * sqrt( g(i)*g(i+1) ) );
    end
end

%% Calculating d and phi

clear;
clc;

Z0 = 50;
Y0 = 1/Z0;

S11 = input('S11: ');
S12 = input('S12: ');

Bp = -1j * Y0 * ((1-S12-S11)/(1+S12+S11));
Bs = -1j * Y0 * ((2 * S12) / ((1+S11)^2 - S12^2));

phi = -atan((2*Bs/Y0) + (Bp/Y0)) - atan(Bp/Y0);
J = Y0 * abs(tan(phi/2 + atan(Bp/Y0)));

%% Calculating l

clear;
clc;

n = 6;
f0 = 1.6 * 10^9;
c = 3 * 10^8;

lda0 = 0.089182700;

% lossless
phi = [-1.4843, -1.381, -1.3789, -1.3785, -1.3789, -1.381, -1.4843];
% lossy
% phi = [-1.4847+0.0015*1i, -1.3814+0.0016*1i, -1.3792+0.0016*1i, -1.3789+0.0016*1i, ...
%     -1.3792+0.0016*1i, -1.3814+0.0016*1i, -1.4847+0.0015*1i];

l = zeros(1, n);

for i = 1:n
    l(i) = 1000*(lda0/(2*pi)) * (pi + 0.5*(phi(i)+phi(i+1)));
end
